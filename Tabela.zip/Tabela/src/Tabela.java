
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Tabela extends JFrame implements ActionListener {

    JTable jtable; // Estrutura da tabela
    DefaultTableModel dtm;// Modelo(permite manipular dados)
    JScrollPane jspane; // painel com barra de rolagem

    // a barra de menu
    JMenuBar menuBar = new JMenuBar();
    // os menus da Janela
    JMenu mArq = new JMenu("Arquivo");
    // os itens do menu da janela
    JMenuItem miLimpar = new JMenuItem("Limpar");

    public Tabela() {
        //Configurando a Janela
        this.setSize(300, 400);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Agenda");

        // arrey com titulos
        String[] arrayTitulos = {"Nome", "Endereço", "E-mail",
            "Telefone", "Cep"};
        //Montando a tabela
        dtm = new DefaultTableModel(arrayTitulos, 0);// add colunas no modelo
        jtable = new JTable(dtm); // add modelo na tabela
        jspane = new JScrollPane(jtable); // add tabela no painel com barra de rol
        this.add(jspane); // add painel com barra de rol na janela

        //Desvinculando o tamanho das celulas com a Janela
        jtable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        //Mostrando a barra de rolagem na horizontal
        jspane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        // adicionando a barra de menu na janela
        this.setJMenuBar(menuBar);
        // adicionando os menus na barra de menus
        menuBar.add(mArq);
        // adicinando os elemenos do menu arquivo
        mArq.add(miLimpar);
        miLimpar.addActionListener(this);
        // Array de dados para 400 linhas na tabela
        String[] arrayDados = new String[5];

        for (int i = 1; i <= 400; i++) {
            arrayDados[0] = "Valor A" + i;
            arrayDados[1] = "Valor B" + i;
            arrayDados[2] = "Valor C" + i;
            arrayDados[3] = "Valor D" + i;
            arrayDados[4] = "Valor E" + i;
            // add linha na tabela
            dtm.addRow(arrayDados);
            
        }
    }

    // método principal
    public static void main(String[] args) {
        Tabela tb = new Tabela();
        tb.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(miLimpar)) {
           String[] arrayTitulos = {"Nome", "Endereço", "E-mail",
            "Telefone", "Cep"}; 
           jtable.setModel(new DefaultTableModel(arrayTitulos, 0));
       
        }
    }
    
}
